<?php
$hall = "";
$capacity = "";
$location    = "";

// Create connection

$db = mysqli_connect('localhost', 'root', '', 'examallocationsystem');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to delete a record
$sql = "DELETE FROM room WHERE $hall='hall', $capacity='capacity', $location='location'";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>