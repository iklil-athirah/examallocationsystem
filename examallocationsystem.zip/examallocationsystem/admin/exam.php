<?php 
//session_start();
// initializing variables
$day = "";
$date = "";

$errors = array(); 
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'examallocationsystem');

// SUBJECT
{ if (isset($_POST['exam'])) {
  // receive all input values from the form
   $day= mysqli_real_escape_string($db, $_POST['day']);
  $date = mysqli_real_escape_string($db, $_POST['date']);
  

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($day)) { array_push($errors, "Day is required"); }
  if (empty($date)) { array_push($errors, "Date is required"); }


  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM `exam` WHERE date='$date'";
  $result = mysqli_query($db, $user_check_query);
  $exam = mysqli_fetch_assoc($result);
  
  
  //if ($staff) { // if user exists
   // if ($staff['username'] === $username) {
     // array_push($errors, "Username already exists");
    //}

    //if ($staff['email'] === $email) {
      //array_push($errors, "email already exists");
    //}
  //}

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
	
	$query = "INSERT INTO `exam`(`Day`, `Date`) VALUES ('$day', '$date')";
	
	mysqli_query($db, $query);
  	//$_SESSION['group'] = $group;
  	$_SESSION['success'] = "You are successful submit";
  	//header('location: exam.php');
  }
}}

?>

<!DOCTYPE html>
<html>

<head>
  <title>Exam Allocation System</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  
  
<body>
  <div class="header"><h2>Examination</h2></div>
	
  <form method="post" action="exam.php">
  	<?php include('functions.php'); ?>
	
	<div class="topnav">
	<a href="index.php">Home</a>
	<a href="staff.php">Staff </a>
	<a href="subject.php">Subject </a>
	<a href="room.php">Room </a>
	<a href="exam.php">Examination </a>
	<a href="algo.php">Algorithm </a>
	<a href="schedule.php">Schedule </a>
</div>
	</div><br>
	
	
	<div class="input-group">
  	  <label>Day</label>
	  <input type="number" placeholder="" step="1" min="1" max="15" name="day" value="<?php echo $day; ?>">
  	</div>
	
	<form action="exam.php">
  <label>
    Date
    <input type="date" name="date" value="<?php echo $insertdate; ?>">
  </label>

  <p><button>Submit</button></p>
</form>


	
	<!--<div class="input-group">
  	  <button type="submit" class="btn" name="exam">Submit</button>
  	</div>
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>-->
	
	

<class="content">

<width = "100%" border = "1" color = "black" align = "center" style="text-transform:uppercase" face="Arial">
<table width = "100%" border = "1" color = "black" align = "center" style="text-transform:uppercase" face="Arial">

<tr>
<th>Day</th>
<th>Date  </th>
</tr>

<?php

$conn = mysqli_connect("localhost", "root", "", "examallocationsystem");

// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT 'Day', 'Date' DATE_FORMAT(`Date`, '%e %M, %Y') FROM 'exam'";
//$sql = "SELECT 'Day', `Date`,  AS dateToPrint FROM 'exam'" ;

$result = $conn->query($sql);

if ($result->num_rows > 0) 

{
	
// output data of each row
while($row = $result->fetch_assoc()) 
{
echo  "<tr>
<td>" . $row["Day"] . " " . "</td>
<td>" . $row["Date"]. " " . "</td>
</tr>"; 
}

echo "</table>";
} 

else { echo "0 results"; }
$conn->close();
?>

  </form>
</body>
</html>



</body>
</html>