<!DOCTYPE html>
<html>

<head>
  <title>Exam Allocation System</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  
  <body>
  <div class="header"><h2>Algorithm</h2></div>
	
  <form method="post" action="algo.php">
  	<?php include('functions.php'); ?>
	
	<div class="topnav">
	<a href="index.php">Home</a>
	<a href="staff.php">Staff </a>
	<a href="subject.php">Subject </a>
	<a href="room.php">Room </a>
	<a href="exam.php">Examination </a>
	<a href="algo.php">Algorithm </a>
	<a href="schedule.php">Schedule </a>
</div>
	</div><br>
	
	

<p>The number of students in a group (1 and 100):</p><br>

<input id="numb" type="text"><br>

<button type="button" onclick="myFunction()">Submit</button><br>

<p id="demo"></p>

<script>
function myFunction() {
  var x, text;

  // Get the value of input field with id="numb"

  x = document.getElementById("numb").value;

  // If x is Not a Number or less than one or greater than 100, output "Input is not Valid"
  // If x is a number between 1 and 100, output "Input is Valid"
   
  if (isNaN(x) || x < 1 || x > 100) {
    text = "Input not valid";
  } 
  
  else if (isNaN(x) || x < 101 && x > 90) {
    text = "Day 1";
  } 
  
  else if (isNaN(x) || x < 91 && x > 80) {
    text = "Day 2";
  } 
  
  else if (isNaN(x) || x < 81 && x > 70) {
    text = "Day 3";
  } 
  
  else if (isNaN(x) || x < 71 && x > 60) {
    text = "Day 4";
  } 
  
  else if (isNaN(x) || x < 61 && x > 50) {
    text = "Day 5";
  } 
  
  else if (isNaN(x) || x < 51 && x > 40) {
    text = "Day 6 & 7";
  } 
  
  else if (isNaN(x) || x < 41 && x > 30) {
    text = "Day 8 & 9";
  } 
  
  else if (isNaN(x) || x < 31 && x > 20) {
    text = "Day 10 & 11";
  } 
  
  else if (isNaN(x) || x < 21 && x > 10) {
    text = "Day 12 & 13";
  } 
  
  else if (isNaN(x) || x < 11 && x > 0) {
    text = "Day 14 & 15";
  } 
  
  //else {
   // text = "Input OK";
  //}
  document.getElementById("demo").innerHTML = text;
}
</script>

</body>
</html> 
