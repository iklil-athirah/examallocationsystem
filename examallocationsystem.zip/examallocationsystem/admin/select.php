<?php//db connection
$db = mysqli_connect('localhost', 'root', '', 'examallocationsystem');
mysql_select_db("database");

//query
$sql=mysql_query("SELECT Course FROM subject");
if(mysql_num_rows($sql)){
	
$select= '<select name="select">';
while($rs=mysql_fetch_array($sql)){
      $select.='<option value="'.$rs['course'].'</option>';
  }
}
$select.='</select>';
echo $select;

?>