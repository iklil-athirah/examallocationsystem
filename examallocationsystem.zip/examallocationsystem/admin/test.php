<?php 
//session_start();
// initializing variables
$code = "";
$course = "";
$group    = "";
$num_students = "";
$duration = "";
$faculty = "";

$errors = array(); 
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'examallocationsystem');


?>

<!DOCTYPE html>
<html>

<head>
  <title>Exam Allocation System</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  
  
<body>
  <div class="header"><h2>Test</h2></div>
	
  <form method="post" action="test.php">
  	<?php include('functions.php'); ?>
	
<div class="topnav">
	<a href="index.php">Home</a>
	<a href="staff.php">Staff </a>
	<a href="subject.php">Subject </a>
	<a href="room.php">Room </a>
	<a href="exam.php">Examination </a>
	<a href="algo.php">Algorithm </a>
	<a href="schedule.php">Schedule </a>
</div>
	</div><br>
	


<class="content">

<width = "100%" border = "1" color = "black" align = "center" style="text-transform:uppercase" face="Arial">
<table width = "100%" border = "1" color = "black" align = "center" style="text-transform:uppercase" face="Arial">

<tr>
<th>Code & Subject Name </th>
<th>Course Name  </th>
<th>Group Course  </th>
<th>Number of Students  </th>
<th>Duration (hours)  </th>
<th>Faculty  </th>
<th>Hall</th>
<th>Capacity  </th>
<th>Location  </th>
<th>Day</th>
<th>Date  </th>
<th>Session </th>
</tr>

<?php

$conn = mysqli_connect("localhost", "root", "", "examallocationsystem");

// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT `Code & Subject Name`, `Course`, `Group Course`, `Number of Students`, `Duration (hours)`, `Faculty`
FROM `subject` ORDER BY `Number of Students` desc";

$sql = "SELECT `Hall`, `Capacity`, `Location`
FROM `room` ORDER BY `Capacity` desc";

$sql = "SELECT `Day`, `Date` FROM `exam`";

$result = $conn->query($sql);

if ($result->num_rows > 0) 

{
	
// output data of each row
while($row = $result->fetch_assoc()) 
{
echo  "<tr>
<td>" . $row["Code & Subject Name"] . " " . "</td>
<td>" . $row["Course"]. " " . "</td>
<td>" . $row["Group Course"]. " " . "</td>
<td>" . $row["Number of Students"]. "  " . "</td>
<td>" . $row["Duration (hours)"]. "  " . "</td>
<td>" . $row["Faculty"]. " " . "</td>
<td>" . $row["Hall"] . " " . "</td>
<td>" . $row["Capacity"]. " " . "</td>
<td>" . $row["Location"]. " " . "</td>
<td>" . $row["Day"] . " " . "</td>
<td>" . $row["Date"]. " " . "</td>
<td>" . $row["Session"]. " " . "</td>
</tr>"; 
}

echo "</table>";
} 

else { echo "0 results"; }
$conn->close();
?>

  </form>
</body>
</html>