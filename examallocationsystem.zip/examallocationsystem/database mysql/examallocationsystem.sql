-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2020 at 01:04 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `examallocationsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `Day` int(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Hall` varchar(100) CHARACTER SET latin1 NOT NULL,
  `Capacity` int(255) NOT NULL,
  `Location` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Hall`, `Capacity`, `Location`) VALUES
('dewan tuanku canselor', 1000, 'DTC RUANG UTAMA'),
('dewan tuanku canselor', 100, 'dtc 1.1'),
('dewan tuanku canselor', 200, 'dtc 1.2'),
('dewan tuanku canselor', 200, 'dtc 2.1'),
('dewan tuanku canselor', 100, 'dtc 2.2'),
('DEWAN KULIAH FAKULTI', 260, 'fsu'),
('DEWAN KULIAH SEDERHANA', 200, 'fsu'),
('DEWAN KULIAH FAKULTI', 260, 'fkp'),
('DEWAN KULIAH SEDERHANA', 200, 'fkp'),
('BILIK KULIAH SEDERHANA', 100, 'fst'),
('BILIK TUTORIAL', 100, 'fst');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `username` varchar(100) CHARACTER SET latin1 NOT NULL,
  `staffname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`username`, `staffname`, `email`, `department`) VALUES
('1170052', 'iklil', 'iklil@gmail.com', 'fst'),
('1170058', 'mawi', 'mawi@gmail.com', 'tamhidi'),
('kjdskljklfdkladjkl', 'ksjdalk', 'klskdl@gmail.com', 'klasdlksa'),
('nia', 'nurul iklil athirah', 'nia@gmail.com', 'fsu'),
('jhjhhhhh', 'jkjkjkjjkjhhh', 'hjhjh@gmail.com', 'jhkjhjkhkj'),
('1170055', 'noor alya syafiqah binti yusoff', 'alyae98@gmail.com', 'FACULTY SCIENCE AND TECHNOLOGY');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `Faculty` varchar(100) CHARACTER SET latin1 NOT NULL,
  `Course` varchar(100) CHARACTER SET latin1 NOT NULL,
  `Code & Subject Name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `Group Course` varchar(10) CHARACTER SET latin1 NOT NULL,
  `Number of Students` int(100) NOT NULL,
  `Duration (hours)` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`Faculty`, `Course`, `Code & Subject Name`, `Group Course`, `Number of Students`, `Duration (hours)`) VALUES
('faculty science technology', 'science computer', 'skj1234 thesis ii', 'group', 81, '3'),
('faculty science technology', 'science computer', 'SKJ2023', 'group', 81, '1'),
('fst', 'science computer', 'wireless', 'group', 81, '2'),
('fst', 'isa', 'skj4343 wireless', 'group', 80, '1'),
('fst', 'computer science', 'thesis 2', 'msc2', 25, '1.5'),
('fst', 'computer science', 'skj4343 wireless', 'ksc', 90, '3'),
('fst', 'science computer', 'skj4343 wireless', 'msc2', 81, '1'),
('fsu', 'foodbio', 'arabic language', 'ksf', 60, '2'),
('fsu', 'financial math', 'english language', 'ksb', 64, '2'),
('fpqs', 'quranic multimedia', 'quran multimedia', 'kqm', 50, '2.5'),
('fsu', 'undang2', 'skj3123', 'ksb', 68, '2.5'),
('fkp', 'hjskjhkjs', 'kshkjsh', 'kshkj', 4, '1'),
('fst', 'jdjkdh', 'computer forensics ', 'kjdhkf', 8, '2.5'),
('fst', 'qc13 isa', 'java programming', 'msc', 8, '3');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `user_type` varchar(100) CHARACTER SET latin1 NOT NULL,
  `password` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `user_type`, `password`) VALUES
(1, '1170058', 'iklil@gmail.com', 'user', '70c929248bbc06249ee4e3f8156a379f'),
(2, 'admin', 'admin@gmail.com', 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(3, '1170052', 'mawi@gmail.com', 'user', '3f2c3763d1eaf85c32a95f12f129e482'),
(4, 'root', 'root@gmail.com', 'user', '63a9f0ea7bb98050796b649e85481845');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
